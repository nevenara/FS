import { AuthenticationRouter } from "./basic-auth/authentication-router";
import { ExpressAppWrapper } from "./http/express-app-wrapper";
import { IAuthenticationController, AuthenticationController } from "./basic-auth/authentication-controller";
import { IAuthentcationRepository, AuthenticationRepository } from "./basic-auth/authentication-repository";
import { DbConnector } from "./db/db-connector";
import { AppLogger } from "./common/app-logger";

export class Bootstrapper{
    public static async init() {
        const dbConnector = this.getDbConnector();

        dbConnector.connectDb(this.getAppLogger());
    }

    public static getDbConnector(){
        return new DbConnector()
    }

    public static getAppLogger(){
        return new AppLogger()
    }

    public static getAuthenticationController(): IAuthenticationController {
        return new AuthenticationController(Bootstrapper.getAuthenticationRepository());
    }

    public static getAuthenticationRepository(): IAuthentcationRepository {
        return new AuthenticationRepository();
    }

    public static getAuthenticationRouter(expressApp): AuthenticationRouter {
        return new AuthenticationRouter(new ExpressAppWrapper(expressApp));
    }
}