export interface IAuthentcationRepository{

}

export class AuthenticationRepository implements IAuthentcationRepository{

}