import { Gender } from "./gender";

export class MainAccount{
    public username: string;
    public email: string;
    public password: string;
    public gender: Gender;
}