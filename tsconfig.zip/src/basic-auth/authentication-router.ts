import { ExpressAppWrapper } from "../http/express-app-wrapper";
import { Bootstrapper } from "../bootstrapper";
import { IAuthenticationController } from "./authentication-controller";
import { LoginRequest } from "./models/login-request";

export class AuthenticationRouter{
    constructor(private readonly expressApp: ExpressAppWrapper){}

    public registerRoutes(): void{
        this.expressApp.post('/login', async (req, res, next) => {

            const request = new LoginRequest();

            request.username = req.body.username;
            request.password = req.body.password;

            const authController: IAuthenticationController = Bootstrapper.getAuthenticationController()

            const response = await authController.login(request);

            res.send(`Login ${request.username} ${request.password}`);            
        })
    }
}