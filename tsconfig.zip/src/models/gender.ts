
export enum Gender{
    Female = 1,
    Male = 2
}