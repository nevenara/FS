export class LoginResponse{
    
}