

export class Environment{
    public static getMongoConnectionString(){
        return process.env.MONGOURL || "mongodb://localhost:27017";
    }
}