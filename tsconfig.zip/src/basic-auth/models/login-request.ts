export class LoginRequest{
    public username: string;
    public password: string;
}