import { ExpressAppWrapper } from "./express-app-wrapper";
import { Bootstrapper } from "../bootstrapper";
const express = require("express");

export class FunsafeServer{
    constructor(private expressApp){
    }

    public async start(): Promise<void>{

        this.registerRoutes();       

        this.createServer();
    }

    private registerRoutes() {
        const authenticationRouter = Bootstrapper.getAuthenticationRouter(this.expressApp);
        authenticationRouter.registerRoutes();


    }

    private createServer() {
        this.expressApp.listen(80);
        console.log('server started.');         
    }
}