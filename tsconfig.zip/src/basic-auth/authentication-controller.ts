import { LoginRequest } from "./models/login-request";
import { LoginResponse } from "./models/login-response";
import { IAuthentcationRepository } from "./authentication-repository";

export interface IAuthenticationController{
    login(request: LoginRequest): LoginResponse;
}
export class AuthenticationController implements IAuthenticationController{
    constructor(private repository: IAuthentcationRepository){}

    public async login(request: LoginRequest): Promise<LoginResponse> {

        // this.authenticationValidator.validte(request)

        // await this.repository.getUserByUserNameAndPassword(request);

        return new LoginResponse();
    }
}