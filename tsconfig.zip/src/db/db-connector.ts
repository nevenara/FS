import { IAppLogger } from "../common/app-logger";
import { Environment } from "../environment";
const mongoose = require("mongoose");

export class DbConnector{
    public async connectDb(logger: IAppLogger): Promise<void>{
        try {
            const uri: string = Environment.getMongoConnectionString();

            mongoose.connect(uri, {
                useNewUrlParser: true,
                useUnifiedTopology: true
            });

            logger.log("Mongoose connect called.");
        } catch (error) {
            logger.error(error, "Failed to connect to mongodb.")
        }
    }
}